<!DOCTYPE html>
<html lang="en" data-bs-theme="auto">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors" />
    <meta name="generator" content="Hugo 0.145.0" />
    <title>Dashboard Template · Bootstrap v5.3</title>

    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/styleKu.css" rel="stylesheet" />
    <link href="assets/simple-datatables/style.css" rel="stylesheet" />
    <link href="assets/bootstrap-icons/bootstrap-icons.css" rel="stylesheet" />
    <link href="assets/boxicons/css/boxicons.min.css" rel="stylesheet" />

    

    <!-- Custom styles for this template -->
    <link href="assets/css/dashboard.css" rel="stylesheet" />
  </head>
  <body>

    <header class="navbar sticky-top bg-dark flex-md-nowrap p-0 shadow" data-bs-theme="dark">
      <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3 fs-6 text-white" href="#"></a>     
    </header>

    <div class="container-fluid">
      <div class="row">
        <div class="sidebar border border-right col-md-3 col-lg-2 p-0 bg-body-tertiary">
          <div class="offcanvas-md offcanvas-end bg-body-tertiary" tabindex="-1" id="sidebarMenu" aria-labelledby="sidebarMenuLabel">
            
            
          </div>
        </div>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
          
        </main>
      </div>
    </div>
   
  </body>
</html>
