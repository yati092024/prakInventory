<div class="offcanvas-body d-md-flex flex-column p-0 pt-lg-3 overflow-y-auto">
    <div class="d-flex flex-column align-items-center p-3 border-bottom">
      <!-- identitas admin -->
        <img src="assets/img/admin.jpg" alt="Admin" class="rounded-circle mb-2" width="80" height="80" />
        <h6 class="mb-0"><?php echo $_SESSION['nama_admin']; ?></h6>
        <small class="text-muted"><?php echo $_SESSION['nama_level']; ?></small>
      <!-- end identitas admin -->
    </div>  
    <!-- side menu -->       
    <ul class="nav flex-column">
      <li class="nav-item">
        <a class="nav-link d-flex align-items-center gap-2 active" aria-current="page" href="index.php">
        <i class='bi bi-house-door'></i>
          Dashboard
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link d-flex align-items-center gap-2" href="index.php?pg=barang">
        <i class='bi bi-book'></i>
          Barang
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link d-flex align-items-center gap-2" href="#">
        <i class='bi bi-person'></i>
          Supplier
        </a>
      </li>
      <li class="nav-item">
          <a class="nav-link d-flex align-items-center gap-2" href="#">
          <i class='bi bi-cart'></i>
            Pembelian
          </a>
      </li>   

      <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-body-secondary text-uppercase">
        <span>Laporan</span>
      </h6>

      <ul class="nav flex-column mb-auto">
        <li class="nav-item">
          <a class="nav-link d-flex align-items-center gap-2" href="#">
          <i class='bi bi-file-earmark-text'></i>
            Data Pembelian
          </a>
        </li>
      </ul>

      <hr class="my-3" />

      <ul class="nav flex-column mb-auto">        
        <li class="nav-item">
          <a class="nav-link d-flex align-items-center gap-2" href="sign-out.php">
          <i class='bi bi-box-arrow-right'></i>
          Sign out
          </a>
        </li>
      </ul>
      
    </ul>
</div>