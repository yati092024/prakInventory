<section class="section section-alert" style="display: none;">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Pesan</h5>
                    <div id="alert-message" class='alert alert-dismissible fade show' role='alert' style="display: none;">
                        <label id="alert-text" style="color: white;"></label>
                        <button type='button' class='btn-close btn-close-white' data-bs-dismiss='alert' aria-label='Close'></button>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
 <!-- judul -->
  
 <!-- selesai judul -->
</div>

<div class="table-responsive small" style="padding-top: 20px; padding-bottom: 20px;">
    
</div>
       

<script src="assets/js/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
    function showAlert(type, message) {
        let alertClass = type === "success" ? "alert-success bg-success" : "alert-danger bg-danger";
        
        $("#alert-message").removeClass("alert-success alert-danger bg-success bg-danger").addClass(alertClass);
        $("#alert-text").text(message);
        $(".section-alert").fadeIn(); // Menampilkan section alert
        $("#alert-message").fadeIn();

        
        setTimeout(function() {
            $(".section-alert").fadeOut(); 
           // redirect setelah fadeOut
        }, 1500); // 1500 milidetik = 1.5 detik
        
    }

    //menutup section-alert ketika tombol btn-close  ditekan
    $(".btn-close").click(function() {
      $(".section-alert").fadeOut();
      // redirect setelah fadeOut
    });

    $("#simpan-form").submit(function(e) {
          e.preventDefault();
          
          // Cek validasi form
          let form = document.getElementById("simpan-form");
          if (!form.checkValidity()) {
              form.classList.add("was-validated"); // Tambahkan class Bootstrap untuk menampilkan pesan error
              return;
          }

         
          $.ajax({
              url: "",
              type: "POST",
              data: formData,
              dataType: "json",
              success: function(response) {
                  console.log(response);
                  if (response.status === "success") {
                      showAlert("success", response.message);
                  } else {
                      showAlert("danger", response.message);
                  }
              },
              error: function(xhr, status, error) {
                  console.log(xhr.responseText);
                  showAlert("danger", "Terjadi kesalahan saat menambah data.");
              }
          });
      });

      
      // Validasi real-time saat user mengisi input
      $("input").on("input", function() {
          if ($(this).val().trim() === "") {
              $(this).addClass("is-invalid");
          } else {
              $(this).removeClass("is-invalid");
          }
      });
    
    
});

</script>