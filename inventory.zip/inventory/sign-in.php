<!DOCTYPE html>
<html lang="en" data-bs-theme="auto">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors" />
    <meta name="generator" content="Hugo 0.145.0" />
    <title>Dashboard Template · Bootstrap v5.3</title>

    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/styleKu.css" rel="stylesheet" />
    <link href="assets/simple-datatables/style.css" rel="stylesheet" />
    <link href="assets/bootstrap-icons/bootstrap-icons.css" rel="stylesheet" />
    <link href="assets/boxicons/css/boxicons.min.css" rel="stylesheet" />
    <link href="assets/css/sign-in.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="assets/css/dashboard.css" rel="stylesheet" />
  </head>
  <body>
    <section class="section section-alert" style="display: none;">
      <div class="row">
          <div class="col-lg-12">
              <div class="card">
                  <div class="card-body">
                      <h5 class="card-title">Pesan</h5>
                      <div id="alert-message" class='alert alert-dismissible fade show' role='alert' style="display: none;">
                          <label id="alert-text" style="color: white;"></label>
                          <button type='button' class='btn-close btn-close-white' data-bs-dismiss='alert' aria-label='Close'></button>
                      </div>

                  </div>
              </div>
          </div>
      </div>
    </section>

    <div class="container-fluid">
        <main class="form-signin w-100 m-auto">
          <form method="post" id="">
            <div class="text-center">
              <img class="mb-0" src="assets/img/logoInv.png" alt="" width="272" height="157">
            </div>

            <div class="form-floating">
              <input type="text" class="form-control" id="floatingInput" placeholder="name">
              <label for="floatingInput">Username</label>
            </div>
            <div class="form-floating">
              <input type="password" class="form-control" id="floatingPassword" placeholder="Password">
              <label for="floatingPassword">Password</label>
            </div>
            
            <button class="btn btn-primary w-100 py-2" type="submit">Sign in</button>
          </form>
        </main>
    </div>
  </body>
</html>

<script src="assets/js/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
      function showAlert(type, message) {
          let alertClass = type === "success" ? "alert-success bg-success" : "alert-danger bg-danger";
          
          $("#alert-message").removeClass("alert-success alert-danger bg-success bg-danger").addClass(alertClass);
          $("#alert-text").text(message);
          $(".section-alert").fadeIn(); // Menampilkan section alert
          $("#alert-message").fadeIn();

          
          setTimeout(function() {
            $(".section-alert").fadeOut(); // Fade out dalam 300ms setelah 2 menit
          }, 15000); // 15000 milidetik
          
      }

      //menutup section-alert ketika tombol btn-close  ditekan
      $(".btn-close").click(function() {
        $(".section-alert").fadeOut();
      });

      $("#login").submit(function(e) {
          e.preventDefault();
          
          // Cek validasi form
          let form = document.getElementById("login");
          if (!form.checkValidity()) {
              form.classList.add("was-validated"); // Tambahkan class Bootstrap untuk menampilkan pesan error
              return;
          }

          let formData = $(this).serialize();

          $.ajax({
              url: "sign-in-cek.php",
              type: "POST",
              data: formData,
              dataType: "json",
              success: function(response) {
                  console.log(response);
                  if (response.status === "success") {
                      alert(response.message);
                     // redirect setelah fadeOut
                  } else {
                      showAlert("danger", response.message);
                  }
              },
              error: function(xhr, status, error) {
                  console.log(xhr.responseText);
                  showAlert("danger", "Username/Password Salah. Silahkan Ulangi.");
              }
          });
      });

      
      // Validasi real-time saat user mengisi input
      $("input").on("input", function() {
          if ($(this).val().trim() === "") {
              $(this).addClass("is-invalid");
          } else {
              $(this).removeClass("is-invalid");
          }
      });
    
    });
</script>
