<section class="section section-alert" style="display: none;">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Pesan</h5>
                    <div id="alert-message" class='alert alert-dismissible fade show' role='alert' style="display: none;">
                        <label id="alert-text" style="color: white;"></label>
                        <button type='button' class='btn-close btn-close-white' data-bs-dismiss='alert' aria-label='Close'></button>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
  
</div>

<div class="table-responsive small">
    
</div>
       

<script src="assets/js/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
    function showAlert(type, message) {
        let alertClass = type === "success" ? "alert-success bg-success" : "alert-danger bg-danger";
        
        $("#alert-message").removeClass("alert-success alert-danger bg-success bg-danger").addClass(alertClass);
        $("#alert-text").text(message);
        $(".section-alert").fadeIn(); // Menampilkan section alert
        $("#alert-message").fadeIn();

        
        setTimeout(function() {
           $(".section-alert").fadeOut(); // Fade out dalam 300ms setelah 2 menit
        }, 15000); // 15000 milidetik
        
    }

    //menutup section-alert ketika tombol btn-close  ditekan
    $(".btn-close").click(function() {
      $(".section-alert").fadeOut();
    });

    // Hapus data tanpa reload
    
    //hapus data selesai
    
});

</script>